public class ConstrutorCarro {
    public static void main(String[] args) {
        Carro carro1 = new Carro("WO093E", 14);
        System.out.println(carro1.getPlaca());
        System.out.println(carro1.getChassi());
    }
}
