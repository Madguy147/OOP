public class Carro {
    private String placa;
    private int numChassi;
      public Carro(String placa, int numChassi) {
        this.placa = placa;
        this.numChassi = numChassi;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getChassi() {
        return numChassi;
    }

   public void setChassi(int numChassi){
    this.numChassi = numChassi;
}
}