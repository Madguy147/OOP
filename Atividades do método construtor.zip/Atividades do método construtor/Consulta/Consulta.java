import java.time.LocalDate;

public class Consulta {
    private String nomeDentista;
    private String nomePaciente;
    private LocalDate data;

    public Consulta(String nomeDentista, String nomePaciente, LocalDate data) {
        this.nomeDentista = nomeDentista;
        this.nomePaciente = nomePaciente;
        this.data = data;
    }

    public String getNomeDentista() {
        return nomeDentista;
    }

    public void setNomeDentista(String nomeDentista) {
        this.nomeDentista = nomeDentista;
    }

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }
}
