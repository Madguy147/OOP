import java.time.LocalDate;
public class ConstrutorConsulta {
    public static void main(String[] args) {
        Consulta consulta = new Consulta("Dra. Ana", "João da Silva", LocalDate.now());
        System.out.println("Dentista: " + consulta.getNomeDentista());
        System.out.println("Paciente: " + consulta.getNomePaciente());
        System.out.println("Data da consulta: " + consulta.getData());
    }
}
