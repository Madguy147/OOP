public class ConstrutorAnimal {
    public static void main(String[] args) {
        Animal animal1 = new Animal("Marrom", 1.5f);
        System.out.println("Cor do animal: " + animal1.getCor());
        System.out.println("Tamanho do animal: " + animal1.getTamanho() + " metros");
    }
}
