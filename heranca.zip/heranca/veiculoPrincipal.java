
public class veiculoPrincipal {
    
    public static void main(String[] args) {
        

    
    Moto moto = new Moto("Huindai", "F12", 2005, "Azul", 5);

    Automovel automovel = new Automovel("Volkswagen", "Gol", 2009, "Cinza", 4, "6 pistões");

    moto.mostrarInformacoes();
    automovel.mostrarInformacoes();

    }
}
