
public class Automovel extends Veiculo {

    private String motor;
    private int numeroPortas;

    public Automovel(String marca, String modelo, int ano, String cor, int numeroPortas, String motor) {
        super(marca, modelo, ano, cor);
        this.numeroPortas = numeroPortas;
        this.motor = motor;
    }

    public String getMotor() {
        return motor;
    }

    public int getNumeroPortas() {
        return numeroPortas;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public void setNumeroPortas(int numeroPortas) {
        this.numeroPortas = numeroPortas;
    }

    @Override

    public void mostrarInformacoes() {
        super.mostrarInformacoes();
        System.out.println("Motor: " + motor + " | Número de Portas: " + numeroPortas);
    }

}
