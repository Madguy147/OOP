
public class Moto extends Veiculo {
    int cilindradas;

    public Moto(String marca, String modelo, int ano, String cor, int cilindradas) {
        super(marca, modelo, ano, cor);
        this.cilindradas = cilindradas;
    }

    public int getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }

    public void mostrarInformacoes() {
        super.mostrarInformacoes();
        System.out.println("Cilindradas: " + cilindradas);
    }

    
}
