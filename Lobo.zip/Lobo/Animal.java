public interface Animal {
    public void dormir();
    public void caminhar();
    public void correr();
    public void emitirSom();
}